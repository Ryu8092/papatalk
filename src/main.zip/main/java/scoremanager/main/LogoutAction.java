
package scoremanager.main;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import tool.Action;

public class LogoutAction extends Action {

    @Override
    public void execute(
            HttpServletRequest req,
            HttpServletResponse res) throws Exception {

        // ログアウト確認画面へ
        req.getRequestDispatcher(
                "/scoremanager/main/logout.jsp"
        ).forward(req, res);
    }
}
